<?php

namespace App\Repositories\CommentReply;

use App\Repositories\BaseRepositoryInterface;

interface CommentReplyRepositoryInterface extends BaseRepositoryInterface {

}