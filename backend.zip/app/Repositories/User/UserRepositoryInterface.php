<?php

namespace App\Repositories\User;

use Illuminate\Http\JsonResponse;

interface UserRepositoryInterface {
}