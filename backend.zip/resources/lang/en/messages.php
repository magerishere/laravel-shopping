<?php

return [
    'Exception' => 'Unknown error. try again',
    'QueryException' => 'Communication error. try again later',
    'UnauthorizedException' => 'This article does not belong to you. You do not have permission to access',
    'ModelNotFoundException' => 'Data does not found',
];