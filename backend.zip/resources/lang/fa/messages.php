<?php

return [
    'Exception' => 'خطای ناشناخته. دوباره تلاش کنید',
    'QueryException' => 'خطا در برقراری ارتباط. لطفا چند لحظه بعد تلاش کنید',
    'UnauthorizedException' => 'این مقاله متعلق به شما نیست. شما اجازه دسترسی ندارید', 
    'ModelNotFoundException' => 'چنین دیتایی وجود ندارد'
    
];