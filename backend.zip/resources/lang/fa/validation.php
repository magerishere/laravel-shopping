<?php


return [
    'image' => ':attribute با فرمت ،jpg، jpeg، png، bmp، gif، svg، ، webp، قابل قبول میباشد',
    'max' => [
        'file' => ':attribute نباید بیشتر از :max کیلوبایت باشد',
       'string' => ':attribute نباید بیشتر از :max کاراکتر باشد',
    ],
    'attributes' => [
        'image' => 'عکس',
        'title' => 'عنوان'
    ]
];